package firewall

import (
	"fmt"
	"goProxy/core/domains"

	"github.com/kor44/gofilter"
)

func EvalFirewallRule(currDomain domains.DomainSettings, variables gofilter.Message, susLv int) int {
	result := susLv

	applyAction := func(action string) {
		var actionInt int
		_, err := fmt.Sscan(action, &actionInt)
		if err != nil {
			fmt.Println("[ ! ] [ Error Evaluating Rule: " + err.Error() + " ]")
			return
		}
		result = actionInt
	}

	modifyResult := func(action string) {
		var actionInt int
		_, err := fmt.Sscan(action[1:], &actionInt)
		if err != nil {
			fmt.Println("[ ! ] [ Error Evaluating Rule: " + err.Error() + " ]")
			return
		}
		switch action[:1] {
		case "+":
			result += actionInt
		case "-":
			result -= actionInt
		}
	}

	for _, rule := range currDomain.CustomRules {
		if rule.Filter.Apply(variables) {
			switch {
			case len(rule.Action) > 0 && (rule.Action[0] == '+' || rule.Action[0] == '-'):
				modifyResult(rule.Action)
			default:
				applyAction(rule.Action)
				return result
			}
		}
	}
	return result
}

