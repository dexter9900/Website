package firewall

import "time"

type RequestLog struct {
	Time    time.Time
	Allowed int
	Total   int
}

func (rl *RequestLog) IncrementAllowed() {
	rl.Allowed++
}

func (rl *RequestLog) IncrementTotal() {
	rl.Total++
}

func (rl *RequestLog) SetTime(t time.Time) {
	rl.Time = t
}
