package server

import (
	"context"
	"crypto/tls"
	"goProxy/core/domains"
	"goProxy/core/firewall"
	"goProxy/core/pnc"
	"goProxy/core/proxy"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/goccy/go-json"
	"github.com/gofiber/fiber/v2"
)

var (
	transportMap = sync.Map{}
)

type callbackListener struct {
	net.Listener
}

type callbackConn struct {
	net.Conn
}

func (ln callbackListener) Accept() (net.Conn, error) {
	conn, err := ln.Listener.Accept()
	if err != nil {
		return nil, err
	}
	return callbackConn{Conn: conn}, nil
}

func (c callbackConn) Close() error {
	firewall.Mutex.Lock()
	delete(firewall.Connections, c.RemoteAddr().String())
	firewall.Mutex.Unlock()
	return c.Conn.Close()
}

func Serve() {

	defer pnc.PanicHndl()

	fbConfig := fiber.Config{
		Network:                   domains.Config.Proxy.Network,
		DisableStartupMessage:     true,
		DisableDefaultContentType: true,
		JSONEncoder:               json.Marshal,
		JSONDecoder:               json.Unmarshal,
		IdleTimeout:               proxy.IdleTimeoutDuration,
		ReadTimeout:               proxy.ReadTimeoutDuration,
		WriteTimeout:              proxy.WriteTimeoutDuration,
	}

	if domains.Config.Proxy.Cloudflare {

		httpServer := fiber.New(fbConfig)

		httpServer.Use(func(c *fiber.Ctx) error {
			Middleware(c)

			return nil
		})

		//service.Handler = http.HandlerFunc(Middleware)

		if err := httpServer.Listen(":80"); err != nil {
			panic(err)
		}
	} else {

		// http to https server
		httpServer := fiber.New(fbConfig)
		httpServer.Use(func(c *fiber.Ctx) error {
			return c.Redirect("https://"+c.Hostname()+c.OriginalURL(), fiber.StatusMovedPermanently)
		})

		// Main https server
		httpsServer := fiber.New(fbConfig)

		tlsHandler := &fiber.TLSHandler{}
		serverListener, errListener := tls.Listen("tcp", ":443", &tls.Config{
			GetConfigForClient: firewall.Fingerprint,
			GetCertificate: func(chi *tls.ClientHelloInfo) (*tls.Certificate, error) {
				tlsHandler.GetClientInfo(chi)
				return domains.GetCertificate(chi)
			},
		})

		loggingLn := callbackListener{Listener: serverListener}

		if errListener != nil {
			panic(errListener)
		}

		httpsServer.SetTLSHandler(tlsHandler)

		httpsServer.Use(func(c *fiber.Ctx) error {
			Middleware(c)

			return nil
		})

		go func() {
			defer pnc.PanicHndl()
			if err := httpsServer.Listener(loggingLn); err != nil {
				panic(err)
			}
		}()

		if err := httpServer.Listen(":80"); err != nil {
			panic(err)
		}
	}
}

func (rt *RoundTripper) RoundTrip(req *http.Request) (*http.Response, error) {

	//Use Proxy Read Timeout
	transport := getTripperForDomain(req.Host)

	//Use inbuild RoundTrip
	resp, err := transport.RoundTrip(req)

	//Connection to backend failed. Display error message
	if err != nil {
		errStrs := strings.Split(err.Error(), " ")
		errMsg := ""
		for _, str := range errStrs {
			if !strings.Contains(str, ".") && !strings.Contains(str, "/") && !(strings.Contains(str, "[") && strings.Contains(str, "]")) {
				errMsg += str + " "
			}
		}
		errPage := `
			<!DOCTYPE html>
<html>
<head>
    <title>Error Connecting to Backend</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://img.freepik.com/free-vector/global-data-security-personal-data-security-cyber-data-security-online-concept-illustration-internet-security-information-privacy-protection_1150-37357.jpg'); /* ???????? 'link_to_your_image.jpg' ?? URL ?????? ??????????? */
            background-size: cover;
            background-position: center;
        }
        .error-container {
            text-align: center;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: rgba(255, 255, 255, 0.9); /* ?????????? ??? ?????????? */
            max-width: 400px;
            width: 90%;
            animation: fadeIn 1s forwards; /* ??????????? ???????? */
        }
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        h1 {
            color: ##000000;
            margin-bottom: 20px;
        }
        p {
            color: ##000000;
            line-height: 1.6;
        }
        .retry-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }
        .retry-button:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>Error Connecting to Backend</h1>
        <p>error connecting to the backend server, refresh page.</p>
        <a href="#" class="retry-button">Refresh</a>
    </div>
</body>
</html>
		`

		return &http.Response{
			StatusCode: http.StatusOK,
			Body:       io.NopCloser(strings.NewReader(errPage)),
		}, nil
	}

	//Connection was successfull, got bad response tho
	if resp.StatusCode > 499 && resp.StatusCode < 600 {
		errPage := `
			<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Error Page</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://img.freepik.com/free-vector/global-data-security-personal-data-security-cyber-data-security-online-concept-illustration-internet-security-information-privacy-protection_1150-37357.jpg'); /* ???????? 'link_to_your_image.jpg' ?? ?????? ?? ???? ???? */
            background-size: cover;
            background-position: center;
        }
        .error-container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }
        h1 {
            font-size: 2.5em;
            color: #333;
            margin-bottom: 10px;
        }
        p {
            font-size: 1.2em;
            color: #333;
        }
        .retry-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            font-size: 1em;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .retry-button:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>backend returned an error</h1>
        <a href="#" class="retry-button">Refresh</a>
    </div>
</body>
</html>

		`

		errBody, errErr := io.ReadAll(resp.Body)
		if errErr == nil && len(errBody) != 0 {
			errPage =
				`
				<!DOCTYPE html>
<html>
<head>
    <title>Error Connecting to Backend</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://img.freepik.com/free-vector/global-data-security-personal-data-security-cyber-data-security-online-concept-illustration-internet-security-information-privacy-protection_1150-37357.jpg'); /* ???????? 'link_to_your_image.jpg' ?? URL ?????? ??????????? */
            background-size: cover;
            background-position: center;
        }
        .error-container {
            text-align: center;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: rgba(255, 255, 255, 0.9); /* ?????????? ??? ?????????? */
            max-width: 400px;
            width: 90%;
            animation: fadeIn 1s forwards; /* ??????????? ???????? */
        }
        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        h1 {
            color: ##000000;
            margin-bottom: 20px;
        }
        p {
            color: ##000000;
            line-height: 1.6;
        }
        .retry-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }
        .retry-button:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>Error Connecting to Backend</h1>
        <p>error connecting to the backend server, refresh page.</p>
        <a href="#" class="retry-button">Refresh</a>
    </div>
</body>
</html>

				`
		}
		resp.Body.Close()

		return &http.Response{
			StatusCode: http.StatusOK,
			Body:       io.NopCloser(strings.NewReader(errPage)),
		}, nil
	}

	return resp, nil
}

func getTripperForDomain(domain string) *http.Transport {

	transport, ok := transportMap.Load(domain)
	if ok {
		return transport.(*http.Transport)
	} else {
		transport := &http.Transport{
			DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
				return (&net.Dialer{
					Timeout: 5 * time.Second,
				}).DialContext(ctx, network, addr)
			},
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
			IdleConnTimeout: 90 * time.Second,
			MaxIdleConns:    10,
		}
		racedTransport, _ := transportMap.LoadOrStore(domain, transport)
		return racedTransport.(*http.Transport)
	}
}

type RoundTripper struct {
}
