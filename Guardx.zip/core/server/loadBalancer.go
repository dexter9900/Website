package server

import (
    "fmt"
    "net/http"
    "net/http/httputil"
    "net/url"
    "sync"
)

var (
    backendServers = []string{"http://35.233.130.175", "http://35.223.191.226"} // Замените на ваши реальные URL'ы серверов
    currentServerIndex = 0
    lbMutex sync.Mutex
)

func getNextServer() string {
    lbMutex.Lock()
    defer lbMutex.Unlock()

    server := backendServers[currentServerIndex]
    currentServerIndex = (currentServerIndex + 1) % len(backendServers)
    return server
}

func loadBalancerMiddleware(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        selectedServer := getNextServer()
        fmt.Printf("Routing request to: %s\n", selectedServer)

        url, err := url.Parse(selectedServer)
        if err != nil {
            http.Error(w, "Bad Gateway", http.StatusBadGateway)
            return
        }

        proxy := httputil.NewSingleHostReverseProxy(url)
        proxy.ServeHTTP(w, r)
    })
}

func main() {
    // Создание нового мультиплексора (router)
    mux := http.NewServeMux()

    // Подключение промежуточного обработчика
    mux.Handle("/", loadBalancerMiddleware(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        fmt.Fprintf(w, "load balancer!")
    })))
}