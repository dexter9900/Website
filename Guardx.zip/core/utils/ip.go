package utils

import (
	"encoding/json"
	"goProxy/core/db"
	"io"
	"net/http"

	"github.com/boltdb/bolt"
)

type IPInfo struct {
	Country struct {
		Code string `json:"alpha2_code"`
	} `json:"country"`
	AS struct {
		Num string `json:"number"`
	} `json:"as"`
}

func GetIpInfo(IP string) (country string, asn string) {
	var ipCountry []byte
	var ipAsn []byte

	db.Instance.DB.View(func(tx *bolt.Tx) error {
		countries := tx.Bucket([]byte("countries"))
		asns := tx.Bucket([]byte("asns"))

		ipCountry = countries.Get([]byte(IP))
		ipAsn = asns.Get([]byte(IP))

		return nil
	})

	if string(ipCountry) != "" {
		return string(ipCountry), string(ipAsn)
	}

	resp, err := http.Get("http://apimon.de/ip/" + IP)
	if err != nil {
		return "UNK", "UNK"
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "UNK", "UNK"
	}

	var data IPInfo
	if err := json.Unmarshal(body, &data); err != nil {
		return "UNK", "UNK"
	}

	updateErr := db.Instance.DB.Update(func(tx *bolt.Tx) error {
		countries := tx.Bucket([]byte("countries"))
		asns := tx.Bucket([]byte("asns"))

		if err := countries.Put([]byte(IP), []byte(data.Country.Code)); err != nil {
			return err
		}
		if err := asns.Put([]byte(IP), []byte(data.AS.Num)); err != nil {
			return err
		}

		return nil
	})
	if updateErr != nil {
		return "UNK", "UNK"
	}

	return data.Country.Code, data.AS.Num
}

func GetOwnIP() (string, error) {
	resp, err := http.Get("http://checkip.amazonaws.com")
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	ip, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	return string(ip[:len(ip)-1]), nil
}


