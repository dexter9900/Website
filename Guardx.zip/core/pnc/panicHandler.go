package pnc

import (
	"fmt"
	"log"
	"os"
	"runtime"
	"time"
)

var logFile *os.File

func InitHndl() error {
	var err error
	logFile, err = os.OpenFile("crash.log", os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0644)
	if err != nil {
		return err
	}
	return nil
}

func PanicHndl() {
	if r := recover(); r != nil {
		stackTrace := make([]byte, 4096)
		length := runtime.Stack(stackTrace, false)

		errMsg := fmt.Sprintf("[ %s ]: Caught Panic: %v\n\n%s\n", time.Now().Format("15:04:05"), r, stackTrace[:length])
		log.Println(errMsg)

		if logFile != nil {
			logFile.WriteString(errMsg)
		}
		panic(r)
	}
}

func LogError(msg string) {
	errMsg := fmt.Sprintf("[ %s ]: Error: %s\n", time.Now().Format("15:04:05"), msg)
	log.Println(errMsg)

	if logFile != nil {
		logFile.WriteString(errMsg)
	}
}
