package proxy

import "time"

const ProxyVersion = 1.5

var (
	Fingerprint string

	WatchedDomain string
	TWidth        int
	THeight       int
	Cloudflare    bool
	MaxLogLength  int

	CpuUsage string
	RamUsage string

	AdminSecret string
	APISecret   string

	CookieSecret string
	CookieOTP    string

	JSSecret string
	JSOTP    string

	CaptchaSecret string
	CaptchaOTP    string

	IdleTimeout       = 5
	ReadTimeout       = 5
	WriteTimeout      = 7
	ReadHeaderTimeout = 5

	RatelimitWindow = 120

	IPRatelimit            int
	FPRatelimit            int
	FailChallengeRatelimit int
	FailRequestRatelimit   int

	RealTimeLogs = false

	// Time-related variables
	CurrHour               int
	CurrHourStr            string
	LastSecondTime         time.Time
	LastSecondTimeFormated string
	LastSecondTimestamp    int
	Last10SecondTimestamp  int

	Initialised = false

	// Duration-related variables
	IdleTimeoutDuration       = time.Duration(IdleTimeout) * time.Second
	ReadTimeoutDuration       = time.Duration(ReadTimeout) * time.Second
	WriteTimeoutDuration      = time.Duration(WriteTimeout) * time.Second
	ReadHeaderTimeoutDuration = time.Duration(ReadHeaderTimeout) * time.Second
)
